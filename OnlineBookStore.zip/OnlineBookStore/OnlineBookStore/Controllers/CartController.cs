﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineBookStore.Interface;
using OnlineBookStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineBookStore.Controllers
{
    
    public class CartController : Controller
    {
        private readonly UserManager<IdentityUser> userManager;
        private IRepositoryWrapper _repository;
        public CartController(IRepositoryWrapper repository, UserManager<IdentityUser> userManager)
        {
            this.userManager = userManager;
            _repository = repository;
        }
        [Authorize]
        public IActionResult Index()
        {
            var user = userManager.GetUserId(HttpContext.User);
            var cart = _repository.Cart.Get(a => a.UserId == user && a.isPending == true).FirstOrDefault();
            if (cart != null)
            {
                var cartItems = _repository.CartDetails.Get(a => a.CartId == cart.CartId).Include(a => a.Book).ToList();
                var total = 0.00m;
                foreach(var item in cartItems)
                {
                    total = total + (item.Quantity * item.Book.Price);
                }
                ViewBag.Total = total;
                return View(cartItems);
            }
            else
            {
                return View();
            }
            
        }
        [Authorize]
        public IActionResult AddToCart(int id)
        {
            var book = _repository.Books.Get(a => a.BookId == id).FirstOrDefault();
            var user = userManager.GetUserId(HttpContext.User);
            var cart = _repository.Cart.Get(a => a.UserId == user && a.isPending == true).FirstOrDefault();
            if (cart != null)
            {
                var checkCart = _repository.CartDetails.Get(a => a.Book.BookId == book.BookId).Include(a => a.Book).FirstOrDefault();
                if(checkCart != null)
                {
                    checkCart.Quantity = checkCart.Quantity + 1;
                    _repository.CartDetails.Update(checkCart);
                    _repository.Save();
                }
                else
                {
                    var cartItem = new CartDetails();
                    cartItem.CartId = cart.CartId;
                    cartItem.Book = book;
                    cartItem.Quantity = 1;
                    _repository.CartDetails.Insert(cartItem);
                    _repository.Save();
                }

                var cartItems = _repository.CartDetails.Get(a => a.CartId == cart.CartId).Include(a => a.Book).ToList();
                return RedirectToAction("Index");
            }
            else
            {
                var newCart = new Cart
                {
                    UserId = user,
                    isPending = true
                };
                _repository.Cart.Insert(newCart);
                _repository.Save();
                var cartId = _repository.Cart.Get(a => a.UserId == user && a.isPending == true).FirstOrDefault();
                var cartItem = new CartDetails();
                cartItem.CartId = cartId.CartId;
                cartItem.Book = book;
                cartItem.Quantity = 1;
                _repository.CartDetails.Insert(cartItem);
                _repository.Save();
                var cartItems = _repository.CartDetails.Get(a => a.CartId == cartId.CartId).Include(a => a.Book).ToList();
                return RedirectToAction("Index");
            }
        }
        public IActionResult UpdateQty(int cartId , int bookId , int qty)
        {
            var cartItems = _repository.CartDetails.Get(a => a.CartId == cartId && a.Book.BookId == bookId).Include(a => a.Book).FirstOrDefault();
            cartItems.Quantity = qty;
            _repository.CartDetails.Update(cartItems);
            _repository.Save();
            return View("Index");
        }
        public IActionResult RemoveItem(int cartId, int bookId)
        {
            var cartItems = _repository.CartDetails.Get(a => a.CartId == cartId && a.Book.BookId == bookId).Include(a => a.Book).FirstOrDefault();
            _repository.CartDetails.Delete(cartItems);
            _repository.Save();
            var check = _repository.CartDetails.Get(a => a.CartId == cartId).Include(a => a.Book).ToList();
            if(check == null)
            {
                var cart = _repository.Cart.Get(a => a.CartId == cartId).FirstOrDefault();
                cart.isPending = false;
                _repository.Cart.Update(cart);
                _repository.Save();
            }
            return View("Index");
        }
        public IActionResult Checkout(int cartId)
        {
            var cart = _repository.Cart.Get(a => a.CartId == cartId).FirstOrDefault();
            var cartItems = _repository.CartDetails.Get(a => a.CartId == cartId).Include(a => a.Book).ToList();
            var total = 0.00m;
            foreach(var item in cartItems)
            {
                total = total + (item.Book.Price * item.Quantity);
            }

            var order = new Order();
            order.Quantity = cartItems.Sum(a => a.Quantity);
            order.OrderDate = DateTime.Now;
            order.UserId = cart.UserId;
            order.Amount = total;
            _repository.Order.Insert(order);
            _repository.Save();

            var getOrder = _repository.Order.Get(a => a.UserId == cart.UserId).OrderByDescending(a => a.OrderDate).FirstOrDefault();
            foreach(var items in cartItems)
            {
                var orderDetails = new OrderDetails();
                orderDetails.OrderId = getOrder.OrderId;
                orderDetails.Book = items.Book;
                orderDetails.Quantity = items.Quantity;

                _repository.OrderDetails.Insert(orderDetails);
                _repository.Save();
            }
            cart.isPending = false;
            _repository.Cart.Update(cart);
            _repository.Save();

            return RedirectToAction("Index", "Home");
        }
    }
}
