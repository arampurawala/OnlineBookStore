﻿using OnlineBookStore.Interface;
using OnlineBookStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineBookStore.Repository
{
    public class OrderRepository : Repository<Order> , IOrderRepository
    {
        public OrderRepository(BookDBContext context)
            : base(context)
        {
        }
    }
}
