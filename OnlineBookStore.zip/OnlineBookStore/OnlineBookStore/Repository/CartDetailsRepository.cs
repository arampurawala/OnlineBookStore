﻿using OnlineBookStore.Interface;
using OnlineBookStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineBookStore.Repository
{
    public class CartDetailsRepository : Repository<CartDetails> , ICartDetailsRepository
    {
        public CartDetailsRepository(BookDBContext context)
            : base(context)
        {
        }
    }
}
