﻿using OnlineBookStore.Interface;
using OnlineBookStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineBookStore.Repository
{
    public class CartRepository : Repository<Cart> , ICartRepository
    {
        public CartRepository(BookDBContext context)
            : base(context)
        {
        }
    }
}
