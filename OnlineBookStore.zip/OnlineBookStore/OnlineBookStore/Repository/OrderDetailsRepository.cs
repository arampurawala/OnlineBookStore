﻿using OnlineBookStore.Interface;
using OnlineBookStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineBookStore.Repository
{
    public class OrderDetailsRepository : Repository<OrderDetails> , IOrderDetailsRepository
    {
        public OrderDetailsRepository(BookDBContext context)
            : base(context)
        {
        }
    }
}
