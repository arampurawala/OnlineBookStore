﻿using OnlineBookStore.Interface;
using OnlineBookStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace OnlineBookStore.Repository
{
    public class RepositoryWrapper : IRepositoryWrapper
    {
        private BookDBContext _context;
        private IBooksRepository _books;
        private ICartRepository _cart;
        private ICartDetailsRepository _cartDetails;
        private IOrderRepository _order;
        private IOrderDetailsRepository _orderDetails;
        public IBooksRepository Books
        {
            get
            {
                if (_books == null)
                {
                    _books = new BookRepository(_context);
                }
                return _books;
            }
        }

        public ICartRepository Cart
        {
            get
            {
                if (_cart == null)
                {
                    _cart = new CartRepository(_context);
                }
                return _cart;
            }
        }
        public ICartDetailsRepository CartDetails
        {
            get
            {
                if (_cartDetails == null)
                {
                    _cartDetails = new CartDetailsRepository(_context);
                }
                return _cartDetails;
            }
        }
        public IOrderRepository Order
        {
            get
            {
                if (_order == null)
                {
                    _order = new OrderRepository(_context);
                }
                return _order;
            }
        }
        public IOrderDetailsRepository OrderDetails
        {
            get
            {
                if (_orderDetails == null)
                {
                    _orderDetails = new OrderDetailsRepository(_context);
                }
                return _orderDetails;
            }
        }
        public RepositoryWrapper(BookDBContext repositoryContext)
        {
            _context = repositoryContext;
        }

        public void Save()
        {
            _context.SaveChanges();
        }
    }
}
