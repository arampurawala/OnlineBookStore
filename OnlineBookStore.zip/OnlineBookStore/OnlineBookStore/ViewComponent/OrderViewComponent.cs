﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using OnlineBookStore.Interface;

namespace OnlineBookStore.ViewComponent
{
    public class OrderViewComponent : Microsoft.AspNetCore.Mvc.ViewComponent
    {
        private readonly UserManager<IdentityUser> userManager;
        private IRepositoryWrapper _repository;
        public OrderViewComponent(IRepositoryWrapper repository, UserManager<IdentityUser> userManager)
        {
            this.userManager = userManager;
            _repository = repository;
        }
        public IViewComponentResult Invoke()
        {
            var user = userManager.GetUserId(HttpContext.User);
            var order = _repository.Order.Get().Where(a => a.UserId == user).ToList();
            return View(order);
        }
    }
}
