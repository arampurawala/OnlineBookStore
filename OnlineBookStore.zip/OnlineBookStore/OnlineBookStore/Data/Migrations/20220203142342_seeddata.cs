﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace OnlineBookStore.Data.Migrations
{
    public partial class seeddata : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "AspNetUserTokens",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(128)",
                oldMaxLength: 128);

            migrationBuilder.AlterColumn<string>(
                name: "LoginProvider",
                table: "AspNetUserTokens",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(128)",
                oldMaxLength: 128);

            migrationBuilder.AlterColumn<string>(
                name: "ProviderKey",
                table: "AspNetUserLogins",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(128)",
                oldMaxLength: 128);

            migrationBuilder.AlterColumn<string>(
                name: "LoginProvider",
                table: "AspNetUserLogins",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(128)",
                oldMaxLength: 128);

            migrationBuilder.InsertData(
                table: "Book",
                columns: new[] { "BookId", "Author", "Description", "ImagePath", "NumberOfPages", "Price", "ReleaseDate", "Title" },
                values: new object[,]
                {
                    { 1, "Robert T. Kiyosaki", null, "RichDad.jpg", 336, 8.97m, new DateTime(2022, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Rich Dad Poor Dad" },
                    { 2, "Robert Greene", null, "power.jpg", 496, 21.49m, new DateTime(2022, 2, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "The 48 Laws of Power" },
                    { 3, "Brianna Wiest", null, "moutain.jpg", 248, 17.20m, new DateTime(2016, 7, 8, 0, 0, 0, 0, DateTimeKind.Unspecified), "The Mountain is You" },
                    { 4, "Randall Munroe", null, "whatif.jpg", 320, 36.63m, new DateTime(2012, 2, 12, 0, 0, 0, 0, DateTimeKind.Unspecified), "What if ?" },
                    { 5, "David Goggins", null, "cant.jpg", 364, 23.56m, new DateTime(2018, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Can't hurt me" },
                    { 6, "James Clear", null, "atomic.jpg", 320, 21.66m, new DateTime(2008, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Atomic Habits" },
                    { 7, "Paulo Coelho", null, "alchemist.jpg", 208, 15.44m, new DateTime(2015, 7, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "The Alchemist" },
                    { 8, "Frank Herbert", null, "dune.jpg", 336, 11.58m, new DateTime(2022, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Dune" },
                    { 9, "Elizabeth Gaskell", null, "north.jpg", 406, 14.99m, new DateTime(2011, 11, 23, 0, 0, 0, 0, DateTimeKind.Unspecified), "North & South" },
                    { 10, "M.A. Rothman", null, "darwin.jpg", 374, 19.63m, new DateTime(2014, 8, 27, 0, 0, 0, 0, DateTimeKind.Unspecified), "Darwin's Cipher" }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Book",
                keyColumn: "BookId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Book",
                keyColumn: "BookId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Book",
                keyColumn: "BookId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Book",
                keyColumn: "BookId",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Book",
                keyColumn: "BookId",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Book",
                keyColumn: "BookId",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Book",
                keyColumn: "BookId",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Book",
                keyColumn: "BookId",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "Book",
                keyColumn: "BookId",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "Book",
                keyColumn: "BookId",
                keyValue: 10);

            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "AspNetUserTokens",
                type: "nvarchar(128)",
                maxLength: 128,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AlterColumn<string>(
                name: "LoginProvider",
                table: "AspNetUserTokens",
                type: "nvarchar(128)",
                maxLength: 128,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AlterColumn<string>(
                name: "ProviderKey",
                table: "AspNetUserLogins",
                type: "nvarchar(128)",
                maxLength: 128,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AlterColumn<string>(
                name: "LoginProvider",
                table: "AspNetUserLogins",
                type: "nvarchar(128)",
                maxLength: 128,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");
        }
    }
}
