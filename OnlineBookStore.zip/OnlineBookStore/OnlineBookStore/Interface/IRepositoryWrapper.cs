﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineBookStore.Interface
{
    public interface IRepositoryWrapper
    {
        ICartDetailsRepository CartDetails { get; }
        ICartRepository Cart { get; }
        IOrderDetailsRepository OrderDetails { get; }
        IOrderRepository Order { get; }
        IBooksRepository Books { get; }
        void Save();


    }
}
