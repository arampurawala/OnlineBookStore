﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineBookStore.Models
{
    public class BookDBContext : IdentityDbContext
    {
        public BookDBContext(DbContextOptions<BookDBContext> options) : base(options)
        {
        }
        public virtual DbSet<Book> Book { get; set; }
        public virtual DbSet<Cart> Cart { get; set; }
        public virtual DbSet<CartDetails> CartDetails { get; set; }
        public virtual DbSet<Order> Order { get; set; }
        public virtual DbSet<OrderDetails> OrderDetails {get;set;}
        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Book>().HasData(
                new Book() { BookId = 1, Title = "Rich Dad Poor Dad", Author = "Robert T. Kiyosaki", ReleaseDate = new DateTime(2022, 01, 01), Price = 8.97m, NumberOfPages = 336,ImagePath = "RichDad.jpg" },
                new Book() { BookId = 2, Title = "The 48 Laws of Power", Author = "Robert Greene", ReleaseDate = new DateTime(2022, 02, 01), Price = 21.49m, NumberOfPages = 496 ,ImagePath = "power.jpg"},
                new Book() { BookId = 3, Title = "The Mountain is You", Author = "Brianna Wiest", ReleaseDate = new DateTime(2016, 07, 08), Price = 17.20m, NumberOfPages = 248 ,ImagePath="mountain.jpg"},
                new Book() { BookId = 4, Title = "What if ?", Author = "Randall Munroe", ReleaseDate = new DateTime(2012, 02, 12), Price = 36.63m, NumberOfPages = 320, ImagePath = "whatif.jpg" },
                new Book() { BookId = 5, Title = "Can't hurt me", Author = "David Goggins", ReleaseDate = new DateTime(2018, 01, 01), Price = 23.56m, NumberOfPages = 364, ImagePath = "cant.jpg" },
                new Book() { BookId = 6, Title = "Atomic Habits", Author = "James Clear", ReleaseDate = new DateTime(2008, 01, 01), Price = 21.66m, NumberOfPages = 320, ImagePath = "atomic.jpg" },
                new Book() { BookId = 7, Title = "The Alchemist", Author = "Paulo Coelho", ReleaseDate = new DateTime(2015, 07, 01), Price = 15.44m, NumberOfPages = 208, ImagePath = "alchemist.jpg" },
                new Book() { BookId = 8, Title = "Dune", Author = "Frank Herbert", ReleaseDate = new DateTime(2022, 01, 01), Price = 11.58m, NumberOfPages = 336, ImagePath = "dune.jpg" },
                new Book() { BookId = 9, Title = "North & South", Author = "Elizabeth Gaskell", ReleaseDate = new DateTime(2011, 11, 23), Price = 14.99m, NumberOfPages = 406, ImagePath = "north.jpg" }, 
                new Book() { BookId = 10, Title = "Darwin's Cipher", Author = "M.A. Rothman", ReleaseDate = new DateTime(2014, 08, 27), Price = 19.63m, NumberOfPages = 374, ImagePath = "darwin.jpg" }

                );
            base.OnModelCreating(builder);
            builder.Entity<IdentityUser>();
        }
    }
}
