﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineBookStore.Models
{
    public class CartDetails
    {
        public int CartDetailsId { get; set; }
        [ForeignKey("Cart")]
        public int CartId { get; set; }
        public virtual Book Book { get; set; }
        public int Quantity { get; set; }
    }
}
